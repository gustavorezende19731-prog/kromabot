# Kromabot

quero um app de traqueamento pessoal meu, vou poder me organizar com faturamento, lucro, quero que a primeira seção seja um dashboard. cujo nome do app vai ser Kroma, Aplique um efeito de vidro fosco (estilo Glassmorphism do iPhone) neste elemento [botões e seções]. Use um fundo semi-transparente branco com opacidade baixa, o efeito 'backdrop-blur' para desfoque do fundo, uma borda fina sutil semi-transparente para dar o efeito de reflexo de luz na quina, e uma sombra suave para dar profundidade. Garanta que o texto por cima continue com alto contraste e legível."

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://kromabot.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/be324229-c07a-46d3-ab1b-c29e026371e4).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```


## Contas e autenticação

O Kroma usa Supabase Auth para cadastro/login com e-mail e senha e login Google.
Para habilitar:

1. Crie um projeto em https://supabase.com.
2. Copie a URL do projeto e a chave pública `anon` para um arquivo `.env` na raiz, seguindo `.env.example`.
3. No Supabase, em **Authentication → Providers**, habilite Email e Google.
4. Configure o provedor Google no painel do Supabase e cadastre a URL de callback indicada pelo próprio painel.
5. Em **Authentication → URL Configuration**, adicione a URL do app às URLs permitidas.
6. Reinicie o servidor de desenvolvimento após preencher `.env`.

Os dados do painel e o perfil são separados por ID de usuário e ficam armazenados no navegador atual (`localStorage`). Isso isola as contas neste dispositivo, mas não sincroniza dados entre dispositivos. Para sincronização em nuvem, será necessário habilitar uma tabela e políticas RLS no banco Supabase.
